"""
PDF Annotator - Backend FastAPI
Cabinet ESTEREL CARTAU
Déploiement Render.com - config fixe
"""
import os, io, re, uuid, hashlib, tempfile
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

import pdfplumber
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.colors import HexColor

from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

# ─── Config fixe ──────────────────────────────────────────────────────────────
USERS = {
    "expert": {
        "password_hash": hashlib.sha256("Expert2025!".encode()).hexdigest(),
        "display_name": "Expert"
    },
    "chef_cabinet": {
        "password_hash": hashlib.sha256("ChefCab2025!".encode()).hexdigest(),
        "display_name": "Chef de Cabinet"
    }
}

TEMPLATES = {
    "fournisseurs": {
        "label": "Grand-livre Fournisseurs",
        "debit_question": "- Avez-vous la facture correspondant a ce mouvement ?",
        "credit_question": "- Comment avez-vous paye cette facture ?"
    },
    "clients": {
        "label": "Grand-livre Clients",
        "debit_question": "- Confirmez-vous que le montant n'a pas ete regle ?",
        "credit_question": "- Possedez-vous la facture correspondant a ce virement ?"
    }
}

# Sessions en mémoire (réinitialisées au redémarrage — normal)
SESSIONS = {}
SESSION_TTL = 8 * 3600  # 8 heures

# ─── FastAPI ───────────────────────────────────────────────────────────────────
app = FastAPI(title="PDF Annotator")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Auth ──────────────────────────────────────────────────────────────────────
def get_session(token: str):
    session = SESSIONS.get(token)
    if not session:
        raise HTTPException(status_code=401, detail="Non authentifié")
    if datetime.fromisoformat(session["expires"]) < datetime.now():
        SESSIONS.pop(token, None)
        raise HTTPException(status_code=401, detail="Session expirée")
    return session

class LoginRequest(BaseModel):
    username: str
    password: str

@app.post("/api/login")
def login(req: LoginRequest):
    user = USERS.get(req.username)
    if not user:
        raise HTTPException(status_code=401, detail="Identifiants incorrects")
    ph = hashlib.sha256(req.password.encode()).hexdigest()
    if ph != user["password_hash"]:
        raise HTTPException(status_code=401, detail="Identifiants incorrects")
    token = str(uuid.uuid4())
    SESSIONS[token] = {
        "username": req.username,
        "display_name": user["display_name"],
        "expires": (datetime.now() + timedelta(seconds=SESSION_TTL)).isoformat()
    }
    return {"token": token, "display_name": user["display_name"], "username": req.username}

@app.post("/api/logout")
def logout(token: str = Form(...)):
    SESSIONS.pop(token, None)
    return {"ok": True}

@app.get("/api/me")
def me(token: str):
    session = get_session(token)
    return {"username": session["username"], "display_name": session["display_name"]}

# ─── Templates (lecture seule) ─────────────────────────────────────────────────
@app.get("/api/templates")
def get_templates(token: str):
    get_session(token)
    return TEMPLATES

# ─── PDF Analysis ──────────────────────────────────────────────────────────────
PAGE_HEIGHT    = 842.0
PAGE_WIDTH     = 595.0
DEBIT_X_RANGE  = (360, 425)
CREDIT_X_RANGE = (445, 510)

def parse_amount(s):
    s2 = s.replace('\xa0','').replace(' ','').replace(',','.')
    try:
        v = float(s2)
        return v if v > 0.01 else None
    except:
        return None

def analyze_page(plumber_page):
    words = plumber_page.extract_words()
    words_sorted = sorted(words, key=lambda w: w['top'])
    rows = []
    current = []
    for w in words_sorted:
        if not current or w['top'] - current[-1]['top'] < 5:
            current.append(w)
        else:
            rows.append(current)
            current = [w]
    if current:
        rows.append(current)

    results  = []
    total_top = None

    for grp in rows:
        texts = [w['text'] for w in grp]
        is_total = 'Total' in texts and not any(
            re.match(r'\d{2}/\d{2}/\d{4}$', t) for t in texts)
        if is_total:
            if total_top is None:
                total_top = min(w['top'] for w in grp)
            continue
        if any(k in texts for k in (
            'Débit','Date','Compte','FINANCEA','Grands-livres','Edition','Grand-Livre')):
            continue

        debits, credits = [], []
        for w in grp:
            v = parse_amount(w['text'])
            if v is None:
                continue
            cx = (w['x0'] + w['x1']) / 2
            if DEBIT_X_RANGE[0] <= cx <= DEBIT_X_RANGE[1]:
                debits.append(v)
            elif CREDIT_X_RANGE[0] <= cx <= CREDIT_X_RANGE[1]:
                credits.append(v)

        if not debits and not credits:
            continue

        row_top    = min(w['top']    for w in grp)
        row_bottom = max(w['bottom'] for w in grp)
        if debits and not credits:
            results.append(dict(type='debit',  top=row_top, bottom=row_bottom))
        elif credits and not debits:
            results.append(dict(type='credit', top=row_top, bottom=row_bottom))
        else:
            results.append(dict(type='both',   top=row_top, bottom=row_bottom))

    return results, total_top or 500

def detect_doc_type(plumber_page):
    words = plumber_page.extract_words()
    full  = ' '.join(w['text'] for w in words).lower()
    return 'clients' if 'client' in full else 'fournisseurs'

def get_account_letter(plumber_page):
    words = plumber_page.extract_words()
    rows  = {}
    for w in words:
        key = round(w['top'], 0)
        rows.setdefault(key, []).append(w)
    for key, ws in sorted(rows.items()):
        texts = [w['text'] for w in ws]
        if 'Compte' in texts:
            idx  = texts.index('Compte')
            rest = texts[idx+1:]
            if rest:
                code   = rest[0].upper()
                letter = code[1] if len(code) > 1 and code[0] in ('C','F') else code[0]
                name   = ' '.join(rest[1:]) if len(rest) > 1 else rest[0]
                return letter, name
    return 'X', 'INCONNU'

def make_overlay(rows, total_top, debit_q, credit_q):
    buf = io.BytesIO()
    c   = rl_canvas.Canvas(buf, pagesize=(PAGE_WIDTH, PAGE_HEIGHT))

    debit_rows  = [r for r in rows if r['type'] in ('debit',  'both')]
    credit_rows = [r for r in rows if r['type'] in ('credit', 'both')]

    def draw_highlight(row, color):
        y_bottom = PAGE_HEIGHT - row['bottom']
        y_top    = PAGE_HEIGHT - row['top']
        h        = y_top - y_bottom
        c.saveState()
        c.setFillColor(color)
        c.setFillAlpha(0.4)
        c.setStrokeAlpha(0)
        c.rect(29, y_bottom, 530, h, fill=1, stroke=0)
        c.restoreState()

    for r in debit_rows:
        draw_highlight(r, HexColor("#ffb3b3"))
    for r in credit_rows:
        draw_highlight(r, HexColor("#b3d1ff"))

    table_bottom_y = PAGE_HEIGHT - total_top - 22
    LINE_HEIGHT    = 22
    lines = []
    if debit_rows:
        lines.append((debit_q,  HexColor("#e05000")))
    if credit_rows:
        lines.append((credit_q, HexColor("#1a6fd4")))

    c.setFont("Helvetica-Bold", 12)
    for i, (text, color) in enumerate(lines):
        y = table_bottom_y - i * LINE_HEIGHT
        c.saveState()
        c.setFillColor(HexColor("#ffffff"))
        c.setFillAlpha(0.9)
        c.rect(29, y - 4, 536, LINE_HEIGHT, fill=1, stroke=0)
        c.restoreState()
        c.saveState()
        c.setFillColor(color)
        c.drawString(34, y + 3, text)
        c.restoreState()

    c.save()
    buf.seek(0)
    return buf

# ─── Process endpoint ──────────────────────────────────────────────────────────
# Stockage temporaire en mémoire (fichiers supprimés après téléchargement)
TEMP_FILES = {}   # file_id -> bytes

@app.post("/api/process")
async def process_pdf(
    token:        str        = Form(...),
    template_key: str        = Form(...),
    file:         UploadFile = File(...)
):
    get_session(token)
    template = TEMPLATES.get(template_key)
    if not template:
        raise HTTPException(status_code=400, detail="Modèle introuvable")

    content  = await file.read()
    debit_q  = template["debit_question"]
    credit_q = template["credit_question"]
    job_id   = str(uuid.uuid4())[:8]

    try:
        pdf_buf = io.BytesIO(content)
        reader  = PdfReader(pdf_buf)
        total_pages = len(reader.pages)

        from collections import defaultdict
        letter_counts = defaultdict(int)
        page_infos    = []

        with pdfplumber.open(io.BytesIO(content)) as pdf_plumber:
            for i in range(total_pages):
                letter, name = get_account_letter(pdf_plumber.pages[i])
                letter_counts[letter] += 1
                page_infos.append((letter, name))

        output_files  = []
        letter_seen   = defaultdict(int)

        with pdfplumber.open(io.BytesIO(content)) as pdf_plumber:
            for i in range(total_pages):
                letter, name = page_infos[i]
                letter_seen[letter] += 1

                rows, total_top = analyze_page(pdf_plumber.pages[i])

                # Ignorer page récapitulative sans mouvements
                if not rows and i == total_pages - 1:
                    continue

                overlay_buf    = make_overlay(rows, total_top, debit_q, credit_q)
                overlay_reader = PdfReader(overlay_buf)

                writer = PdfWriter()
                # Relire la page depuis un buffer frais
                fresh_buf = io.BytesIO(content)
                fresh_reader = PdfReader(fresh_buf)
                page = fresh_reader.pages[i]
                page.merge_page(overlay_reader.pages[0])
                writer.add_page(page)

                doc_type = detect_doc_type(pdf_plumber.pages[i])
                prefix   = "Clients" if doc_type == "clients" else "Fournisseurs"

                if letter_counts[letter] > 1:
                    fname = f"{prefix} {letter}{letter_seen[letter]}.pdf"
                else:
                    fname = f"{prefix} {letter}.pdf"

                out_buf = io.BytesIO()
                writer.write(out_buf)
                file_id = f"{job_id}_{i}"
                TEMP_FILES[file_id] = (fname, out_buf.getvalue())

                nd = len([r for r in rows if r['type'] in ('debit','both')])
                nc = len([r for r in rows if r['type'] in ('credit','both')])
                output_files.append({
                    "filename": fname,
                    "file_id":  file_id,
                    "debits":   nd,
                    "credits":  nc,
                    "account":  name
                })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {"job_id": job_id, "files": output_files}

@app.get("/api/download/{file_id}")
def download_file(file_id: str, token: str):
    get_session(token)
    entry = TEMP_FILES.get(file_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Fichier introuvable ou expiré")
    fname, data = entry
    return FileResponse(
        path=_write_temp(data),
        filename=fname,
        media_type="application/pdf"
    )

def _write_temp(data: bytes) -> str:
    """Write bytes to a named temp file and return its path."""
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    tmp.write(data)
    tmp.flush()
    tmp.close()
    return tmp.name

# ─── Serve React frontend ──────────────────────────────────────────────────────
frontend_dist = Path(__file__).parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="static")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
