export default function Navbar({ user, page, onNav, onLogout }) {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        ESTEREL CARTAU
        <span>Cabinet d'expertise comptable</span>
      </div>
      <div className="navbar-nav">
        <button className="nav-btn active">Traitement PDF</button>
      </div>
      <div className="navbar-user">
        <span className="user-name">{user.display_name}</span>
        <button className="btn-logout" onClick={onLogout}>Déconnexion</button>
      </div>
    </nav>
  )
}
