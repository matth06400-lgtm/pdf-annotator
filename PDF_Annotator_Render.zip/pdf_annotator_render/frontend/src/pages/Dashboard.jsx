import { useState, useEffect, useRef } from "react"

export default function Dashboard({ token }) {
  const [templates, setTemplates]       = useState({})
  const [selectedTemplate, setSelected] = useState("")
  const [file, setFile]                 = useState(null)
  const [dragOver, setDragOver]         = useState(false)
  const [loading, setLoading]           = useState(false)
  const [progress, setProgress]         = useState(0)
  const [results, setResults]           = useState(null)
  const [jobId, setJobId]               = useState(null)
  const [error, setError]               = useState("")
  const fileInputRef = useRef()

  useEffect(() => {
    fetch(`/api/templates?token=${token}`)
      .then(r => r.json())
      .then(data => {
        setTemplates(data)
        // Auto-select first template
        const keys = Object.keys(data)
        if (keys.length > 0) setSelected(keys[0])
      })
  }, [token])

  const handleFile = (f) => {
    if (f && f.type === "application/pdf") {
      setFile(f)
      setResults(null)
      setError("")
    } else if (f) {
      setError("Veuillez sélectionner un fichier PDF.")
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    const f = e.dataTransfer.files[0]
    handleFile(f)
  }

  const handleProcess = async () => {
    if (!file || !selectedTemplate) return
    setLoading(true)
    setProgress(10)
    setError("")
    setResults(null)

    const fd = new FormData()
    fd.append("token", token)
    fd.append("template_key", selectedTemplate)
    fd.append("file", file)

    try {
      setProgress(30)
      const res = await fetch("/api/process", { method: "POST", body: fd })
      setProgress(80)
      if (!res.ok) {
        const data = await res.json()
        setError(data.detail || "Erreur lors du traitement")
        return
      }
      const data = await res.json()
      setProgress(100)
      setResults(data.files)
      setJobId(data.job_id)
    } catch (e) {
      setError("Erreur de connexion au serveur")
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = (fileId) => {
    window.open(`/api/download/${encodeURIComponent(fileId)}?token=${token}`, "_blank")
  }

  const handleDownloadAll = () => {
    if (!results) return
    results.forEach((r, i) => {
      setTimeout(() => handleDownload(r.file_id), i * 400)
    })
  }

  const handleReset = () => {
    setFile(null)
    setResults(null)
    setJobId(null)
    setProgress(0)
    setError("")
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  const template = templates[selectedTemplate]

  return (
    <div>
      <div className="page-header">
        <h2>Traitement des PDF</h2>
        <p>Importez un grand-livre, choisissez un modèle et téléchargez les fichiers annotés.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>

        {/* Left column */}
        <div>
          {/* Template selector */}
          <div className="card">
            <div className="section-label">Modèle de questions</div>
            <div className="template-grid">
              {Object.entries(templates).map(([key, tpl]) => (
                <div
                  key={key}
                  className={`template-card ${selectedTemplate === key ? "selected" : ""}`}
                  onClick={() => setSelected(key)}
                >
                  <div className="tc-icon">
                    {key === "fournisseurs" ? "📤" : key === "clients" ? "📥" : "📄"}
                  </div>
                  <div className="tc-label">{tpl.label}</div>
                  <div className="tc-questions">
                    <span style={{ color: "var(--debit-color)" }}>D : </span>{tpl.debit_question.replace(/^- /, "")}
                    <br /><br />
                    <span style={{ color: "var(--credit-color)" }}>C : </span>{tpl.credit_question.replace(/^- /, "")}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upload */}
          <div className="card mt-16">
            <div className="section-label">Fichier PDF</div>
            <div
              className={`upload-zone ${dragOver ? "drag-over" : ""}`}
              onDragOver={e => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => !file && fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                style={{ display: "none" }}
                onChange={e => handleFile(e.target.files[0])}
              />
              {!file ? (
                <>
                  <div className="upload-icon">📂</div>
                  <h3>Déposer un PDF ici</h3>
                  <p>ou cliquer pour parcourir</p>
                  <p style={{ marginTop: 8, fontSize: "0.78rem" }}>Grand-livre fournisseurs ou clients</p>
                </>
              ) : (
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: "2rem", marginBottom: 8 }}>✅</div>
                  <div style={{ fontWeight: 600, color: "var(--navy)" }}>{file.name}</div>
                  <div style={{ fontSize: "0.82rem", color: "var(--gray-400)", marginTop: 4 }}>
                    {(file.size / 1024).toFixed(0)} Ko
                  </div>
                </div>
              )}
            </div>

            {file && (
              <div className="row-center mt-16">
                <button
                  className="btn-process"
                  onClick={handleProcess}
                  disabled={loading || !selectedTemplate}
                >
                  {loading
                    ? <><span className="spinner" style={{ borderTopColor: "var(--navy)", borderColor: "rgba(26,39,68,0.2)" }} /> Traitement…</>
                    : <><span>⚙️</span> Lancer l'annotation</>
                  }
                </button>
                {!loading && (
                  <button className="btn-edit" onClick={handleReset}>Annuler</button>
                )}
              </div>
            )}

            {loading && (
              <div className="progress-bar mt-16">
                <div className="progress-fill" style={{ width: `${progress}%` }} />
              </div>
            )}

            {error && <div className="error-msg" style={{ marginTop: 12 }}>{error}</div>}
          </div>
        </div>

        {/* Right column - results */}
        <div>
          {results ? (
            <div className="card">
              <div className="results-header">
                <h3>✅ {results.length} fichier{results.length > 1 ? "s" : ""} généré{results.length > 1 ? "s" : ""}</h3>
                {results.length > 1 && (
                  <button className="btn-download-all" onClick={handleDownloadAll}>
                    Tout télécharger
                  </button>
                )}
              </div>

              <div style={{ maxHeight: 520, overflowY: "auto" }}>
                {results.map(r => (
                  <div key={r.file_id} className="result-item">
                    <div style={{ flex: 1 }}>
                      <div className="result-filename">{r.filename}</div>
                      {r.account && <div className="result-account">{r.account}</div>}
                      <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                        {r.debits > 0 && (
                          <span className="badge badge-debit">
                            {r.debits} débit{r.debits > 1 ? "s" : ""}
                          </span>
                        )}
                        {r.credits > 0 && (
                          <span className="badge badge-credit">
                            {r.credits} crédit{r.credits > 1 ? "s" : ""}
                          </span>
                        )}
                      </div>
                    </div>
                    <button className="btn-download" onClick={() => handleDownload(r.file_id)}>
                      ⬇ Télécharger
                    </button>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 16, textAlign: "right" }}>
                <button className="btn-edit" onClick={handleReset}>Nouveau traitement</button>
              </div>
            </div>
          ) : (
            <div className="card">
              <div className="empty-state">
                <div className="es-icon">📋</div>
                <p>Les fichiers annotés apparaîtront ici</p>
                <p style={{ fontSize: "0.8rem", marginTop: 8 }}>
                  Sélectionnez un modèle, importez un PDF et lancez le traitement.
                </p>
              </div>

              {template && (
                <div style={{ marginTop: 20, padding: "16px", background: "var(--gray-50)", borderRadius: "var(--radius)", fontSize: "0.85rem" }}>
                  <div style={{ fontWeight: 600, color: "var(--navy)", marginBottom: 10 }}>
                    Modèle sélectionné : {template.label}
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
                    <span className="badge badge-debit">Débit</span>
                    <span style={{ color: "var(--gray-600)" }}>{template.debit_question}</span>
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                    <span className="badge badge-credit">Crédit</span>
                    <span style={{ color: "var(--gray-600)" }}>{template.credit_question}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
