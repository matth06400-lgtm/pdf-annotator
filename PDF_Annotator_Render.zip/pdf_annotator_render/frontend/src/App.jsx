import { useState, useEffect } from "react"
import Login from "./pages/Login"
import Dashboard from "./pages/Dashboard"
import Navbar from "./components/Navbar"

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("token") || "")
  const [user, setUser]   = useState(() => {
    const u = localStorage.getItem("user")
    return u ? JSON.parse(u) : null
  })
  const [page, setPage] = useState("dashboard")

  useEffect(() => {
    if (!token) return
    fetch(`/api/me?token=${token}`)
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => setUser(data))
      .catch(() => handleLogout())
  }, [token])

  const handleLogin = (tok, userData) => {
    setToken(tok)
    setUser(userData)
    localStorage.setItem("token", tok)
    localStorage.setItem("user", JSON.stringify(userData))
  }

  const handleLogout = () => {
    if (token) {
      const fd = new FormData()
      fd.append("token", token)
      fetch("/api/logout", { method: "POST", body: fd })
    }
    setToken("")
    setUser(null)
    localStorage.removeItem("token")
    localStorage.removeItem("user")
  }

  if (!token || !user) return <Login onLogin={handleLogin} />

  return (
    <div className="app-shell">
      <Navbar user={user} page={page} onNav={setPage} onLogout={handleLogout} />
      <main className="main-content">
        {page === "dashboard" && <Dashboard token={token} />}
      </main>
    </div>
  )
}
